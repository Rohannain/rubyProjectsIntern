require "test_helper"

class ScreeningTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
