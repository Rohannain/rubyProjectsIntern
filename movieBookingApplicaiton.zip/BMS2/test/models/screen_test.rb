require "test_helper"

class ScreenTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
