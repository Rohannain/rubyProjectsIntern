import { Application } from "@hotwired/stimulus"

const application = Application.start()

// Configure Stimulus development experience
application.debug = false
window.Stimulus   = application
// Find the flash notice element and fade it out after 1 second
document.addEventListener("DOMContentLoaded", function() {
    const flashNotice = document.querySelector('.alert');
    if (flashNotice) {
      setTimeout(function() {
        flashNotice.style.transition = "opacity 0.5s";
        flashNotice.style.opacity = 0;
        setTimeout(function() {
          flashNotice.remove();
        }, 500);
      }, 1000);
    }
  });
export { application }
