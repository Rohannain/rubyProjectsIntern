class TheatresController < ApplicationController

end