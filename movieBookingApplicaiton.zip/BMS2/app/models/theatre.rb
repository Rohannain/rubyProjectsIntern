class Theatre < ApplicationRecord
    has_many :screens
    has_many :movies, through: :screens
end
