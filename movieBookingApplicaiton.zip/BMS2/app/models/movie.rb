class Movie < ApplicationRecord
    has_many :screenings
    has_many :screens, -> { distinct }, through: :screenings
    has_many :theatres, through: :screens
end
