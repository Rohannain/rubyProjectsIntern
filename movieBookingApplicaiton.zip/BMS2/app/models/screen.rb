class Screen < ApplicationRecord
    has_many :screenings
    belongs_to :theatre
end
