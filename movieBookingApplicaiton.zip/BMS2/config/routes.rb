Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"

  root "movies#index"
  get "users/new", to: "users#new", as: :new_user
  post "users/new", to: "users#create"

  get "/login", to: "sessions#new"
  post "/login", to: "sessions#create"

  delete "/logout", to: "sessions#destroy"

  get "movies/:id", to: "movies#show", as: :movies
  get "theatre/:id", to: "theatres#show", as: :theatres
  get "bookings", to: "users#booking", as: :bookings

  get "bookings/:id/cancel", to: "users#cancel_booking", as: :cancel_bookings
  get "book/:screening_id", to: "users#book", as: :book

end

 
